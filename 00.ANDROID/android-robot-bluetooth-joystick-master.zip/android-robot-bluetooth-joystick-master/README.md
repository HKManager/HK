#Android Bluetooth Joystick

##Feature

 * Dual Joystick (left & right).
 * Config buttons for left and right joystick support 16 commands.
 * Config buttons forHold stick mode (Press and hold left or right joystick) support 16 commands.
 * Support motion constrain for horizontal or vertical.
 * Support video streaming from robot camera to mobile, joystick overlay on the video.

 ##Screenshot

![](https://lh3.googleusercontent.com/-rea1EQdAw9c/VlMAv97tpPI/AAAAAAAAV-0/a5o7Hs9S1pU/s640-Ic42/DFG_2015-11-23-17-30-58.png)

![](https://lh3.googleusercontent.com/-vn-EGT90qI8/VlMAW6o9VlI/AAAAAAAAV-k/op1B506TYq4/s640-Ic42/DFG_2015-11-23-18-17-54.png)

![](https://lh3.googleusercontent.com/-CAgsHaf_w38/VlMAWEgk53I/AAAAAAAAV-g/wSX8009nm2Y/s640-Ic42/DFG_2015-11-23-18-18-05.png)

![](https://lh3.googleusercontent.com/-_mdG1BwqEl0/VlMAob0gu4I/AAAAAAAAV-s/llG5J7mynr4/s640-Ic42/DFG_2015-11-23-18-18-15.png)

