package com.kakao.auth;

/**
 * @author kevin.kang. Created on 2017. 5. 19..
 */

public class SingleNetworkTaskTest {
}
