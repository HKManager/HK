/**
 * Provides Plus Friend functionality, such as adding or chatting with Plus Friends.
 */
package com.kakao.plusfriend;