/**
 * Provide KakaoTalk API with message template v2.
 */
package com.kakao.kakaotalk.v2;