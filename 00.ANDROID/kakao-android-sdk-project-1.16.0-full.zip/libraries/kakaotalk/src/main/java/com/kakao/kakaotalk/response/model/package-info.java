/**
 * 카카오톡 API의 응답 중 별도의 클래스가 필요한 경우를 위한 패키지.
 *
 * Package fro additional response models required by KakaoTalk API/
 */
package com.kakao.kakaotalk.response.model;