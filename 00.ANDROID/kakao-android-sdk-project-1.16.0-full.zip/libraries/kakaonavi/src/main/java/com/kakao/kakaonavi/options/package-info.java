/**
 * Contains enum classes for configuring KakaoNavi parameters.
 */
package com.kakao.kakaonavi.options;