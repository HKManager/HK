/**
 * Provide API to send Kakaotalk Link messages with message template v2.
 */
package com.kakao.kakaolink.v2;