/**
 * Provide callbacks for network requests.
 */
package com.kakao.network.callback;