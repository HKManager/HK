package com.kakao.sdk.sample.kakaostory;

import com.kakao.sdk.sample.friends.FriendsMainActivity;

/**
 * @author leo.shin
 */
public class KakaoStoryFriendListActivity extends FriendsMainActivity {
}
