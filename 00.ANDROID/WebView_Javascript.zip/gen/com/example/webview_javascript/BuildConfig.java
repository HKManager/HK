/** Automatically generated file. DO NOT MODIFY */
package com.example.webview_javascript;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}