SimpleJsGame
============

A really simple Javascript based game I've been working on during lunchtime using TypeScript.

This project is/was a great way for me to have a play with TypeScript (which has blown me away so far) and flex my limited JS skills.

It's only really been tested in the latest version of Chrome so far, though it may work in other browsers.

You can find [a working demo here](http://josephwoodward.co.uk/content/simplejsgame/).
