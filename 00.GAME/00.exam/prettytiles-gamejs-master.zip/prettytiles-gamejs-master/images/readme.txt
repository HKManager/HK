Art from http://opengameart.org/content/isometric-64x64-outside-tileset
Yar
CC-BY 3.0