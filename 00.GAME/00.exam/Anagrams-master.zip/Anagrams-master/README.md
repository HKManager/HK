### Anagrams

In this game, you must select the choice which is an anagram of the current word being displayed. You will have 5 seconds to choose, and your goal is to get as many correct as possible until you lose.

![](https://raw.githubusercontent.com/saadq/Anagrams/master/screenshots/ScreenShot-Anagrams.png)

Click [here](http://saadq.github.io/Anagrams/) to play!