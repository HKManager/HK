# Pokemon-Emerald
This is a simple version of Pokemon Emerald written in JavaScript, HTML and CSS.
I programmed the battle part and global functions of the game.
(global functions are functions that keep track of the game status, generate monsters, etc.)
This project is done as my Independent Student Unit Project in high school.
