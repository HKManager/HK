# Pokemon-Emerald
A nodejs game made in javascript. 

#features
* world
  * Load the world
  * can jump/teleport between worlds
  * block animation
* player
  * place on world
  * movment
  * camera movment on world
  * creen eagles made
  * movment animation
  * read signs
  * talk to npc
  * collision detaction
* Npc
  * movment
  * movment animation
  * collision detaction

and more..
