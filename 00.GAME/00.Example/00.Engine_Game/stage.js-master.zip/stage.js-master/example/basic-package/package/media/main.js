Stage({
  name : 'package',
  image : {
    src : './main.png'
  }
});
