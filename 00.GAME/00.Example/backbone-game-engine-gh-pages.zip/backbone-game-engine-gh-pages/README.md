Backbone Game Engine
====================

An elementary HTML5 Game Engine built on Backbone.

Documentation and examples can be found here:
http://martindrapeau.github.io/backbone-game-engine

* * *

Copyright (c) Martin Drapeau<br/>
Licensed under the MIT @license