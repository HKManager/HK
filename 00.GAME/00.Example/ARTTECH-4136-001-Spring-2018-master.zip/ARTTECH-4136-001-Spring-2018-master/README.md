# ARTTECH 4136-1: Experimental Game Lab
## Final Project
This repository is for my Final Project for a course called Experimental Game Lab (ARTTECH 4136-1).  
For my final project, I decided to create a simple RPG game using JavaScript.  

The game is built on and developed from a foundation work - a tutorial project of learning HTML5 games [Udemy tutorial](https://www.udemy.com/how-to-program-games/learn/v4/overview).

### Assets
The sprites that I used for this game: (http://bit.ly/dungeonTiles32)[http://bit.ly/dungeonTiles32].
