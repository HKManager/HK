# HTML Platform Game
This is a repository for the HTML5 Platform Game course at https://devdojo.com
![HTML PLATFORM GAME](https://devdojo.com/uploads/images/April2016/html5-game.png "HTML5 Game Course")