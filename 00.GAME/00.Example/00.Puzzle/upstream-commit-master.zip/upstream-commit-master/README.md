Upstream Commit
===

[Play the GitHub Game Off 2015 version!](https://razh.github.io/upstream-commit/ggo15)

![Screenshot](./images/uc-1000x480.png)

Based on [gbatha's PolyBranch](https://www.github.com/gbatha/PolyBranch).
