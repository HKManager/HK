HTML5RPG
========

A cross-platform HTML5 2D RPG template

******Download the version of EnchantJS used [here]**(http://github.com/uei/enchant.js-builds/archive/v0.8.2-b.zip)

**Download the version of Cordova (PhoneGap) [here]**(http://archive.apache.org/dist/cordova/platforms/cordova-wp8-3.5.0.zip)