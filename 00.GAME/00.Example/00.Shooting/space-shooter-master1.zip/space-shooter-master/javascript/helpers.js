/** helpers.js **/
/** HELPER FUNCTIONS **/


function collides(a, b) {
	return a.x < b.x + b.width &&
		a.x + a.width > b.x &&
		a.y < b.y + b.height &&
		a.y + a.height > b.y;
}

/**
 * Returns a number whose value is limited to the given range.
 *
 * Example: limit the output of this computation to between 0 and 255
 * (x * 255).clamp(0, 255)
 *
 * @param {Number} min The lower boundary of the output range
 * @param {Number} max The upper boundary of the output range
 * @returns A number in the range [min, max]
 * @type Number
 * Source: http://stackoverflow.com/a/11409944/1689605
 */
Number.prototype.clamp = function(min, max) {
  return Math.min(Math.max(this, min), max);
};