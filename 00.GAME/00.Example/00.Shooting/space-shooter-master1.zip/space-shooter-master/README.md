space-shooter
=============

A quick and dirty HTML5 space shooter game, based on a [HTML5 rocks tutorial ](http://www.html5rocks.com/en/tutorials/canvas/notearsgame/).

Mostly an exploration of simple HTML5 game design and canvas API.
