# js-html5-space-shooter - wip 
A simple JS &amp; HTML5 Space Shooter game.

open /dist/index.html

![screenshot](https://i.postimg.cc/bwS80NzQ/cover.png)
