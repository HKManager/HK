canvas_danmaku
==============

Danmaku (bullet hell) style shooting game using HTML5 canvas and written in Javascript.

This was basically a test to see how much I could get moving around smoothly on my little old laptop. Last time I checked, it ran pretty smooth, although I'm currently running on a much more powerful machine.

I'm sure either machine could handle a LOT more if the game was written in c, but that wasn't the point ;) Anyway, feel free to clone the repo and tweak the parameters to see how far it can go. Maybe I'll expose them on the web page one day.

Play it here:<br>
https://rawgithub.com/andyp123/canvas_danmaku/master/index.html

**KEYS**:<br>
cursor keys: move ship<br>
Z: fire primary<br>
x: fire secondary<br>
shift + s: toggle sound<br>
shift + d: toggle debug mode<br>
ctrl + drag (debug): move camera<br>
c (debug): reset camera position
