# Space-Shooter-Game

It is a simple space shooter game made using javascript, html5 and css. 

# Controls: 
Spacebar to shoot and arrow keys to move the spaceship. All the best!
![alt tag](https://raw.githubusercontent.com/rishimadhok/Space-Shooter-Game/master/space-shooter.png)

# To run this game simply clone or download this repository and then open spaceshooter.html using any web browser.
