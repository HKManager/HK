Learn Phaser JS From [HTML5 Shoot 'em Up in an Afternoon](https://leanpub.com/html5shootemupinanafternoon)

[Play Demo](http://phonbopit.github.io/learn-html5-shmup)
---

### Sync Master and gh-pages

[Automatically sync master and gh-pages](http://stackoverflow.com/questions/5807459/github-mirroring-gh-pages-to-master#answer-7472481)

