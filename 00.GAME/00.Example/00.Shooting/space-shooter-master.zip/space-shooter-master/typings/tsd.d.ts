
/// <reference path="es6/core-js.d.ts" />
/// <reference path="moment/moment.d.ts" />
/// <reference path="custom.system.d.ts" />
/// <reference path="angular2/angular2.dev-alpha.37.d.ts" />
/// <reference path="angular2/angular2.router.dev-alpha.37.d.ts.ts" />
/// <reference path="angular2/angular2.http.dev-alpha.37.d.ts.ts" />
/// <reference path="rx/rx.d.ts" />
/// <reference path="rx/rx-lite.d.ts" />
