#HTML5 Canvas Arcade Shooter Game
[http://splintercode.github.io/space-shooter/](http://splintercode.github.io/space-shooter/)
Small ES6 JavaScript and html5 canvas game. Work in progress. This is a small side project to test out
some of the upcoming new ES6 features.

Objective of the game dodge the asteroids or shoot them to get the highest score. Each game starts with three lives.

###Controls
- A,S,D,F, and Up, Right, Down, Left keys to move ship.
- (Space bar) to fire laser.
- (P) to pause.
- (Enter) to start game.
- Touch controls to come soon!
