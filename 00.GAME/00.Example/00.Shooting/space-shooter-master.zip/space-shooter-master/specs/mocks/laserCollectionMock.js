class LaserCollectionMock {
    constructor() {
        this.maxLasers = 10;
        this.list = [];
    }

    update() {

    }

    draw() {

    }

    fire() {

    }
}

export {LaserCollectionMock};