# Fighter-Down
A simple top-down shoot-em-up game written in JavaScript using html5 canvas. Used as a learning experience in developing 2d games. Try it [here](https://mirror12k.github.io/fighter-down/)! screenshot:

![screenshot](screenshot.png)
