simple-shooter
==============

HTML5 2D Shooter Game

To play it, simply open in the browser the file `dist/index.html`

This little game can be found at: [www.marco-ciampini.com/simple-shooter/](http://www.marco-ciampini.com/simple-shooter/index.html "My personal website")


Build instructions:
-------------------

1. `cd` to the project root
2. modify files (`dist/index.html`, `dist/img/[images]`, `source/js/[javascript files]`, `source/scss/app.scss`)
2. `grunt`


Credits:
--------

- http://blog.sklambert.com/
- http://atomicrobotdesign.com/blog/htmlcss/build-a-vertical-scrolling-shooter-game-with-html5-canvas-part-1/
- https://www.udacity.com/course/cs255
- http://www.html5gamedevelopment.com/
