# JS13k17

play on http://2017.js13kgames.com/entries/lossst

all rights reserved (no commercial use allowed!)
