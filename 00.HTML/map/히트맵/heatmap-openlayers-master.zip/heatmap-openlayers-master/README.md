Sample code showing the use of [heatmap.js](http://www.patrick-wied.at/static/heatmapjs/) library with OpenLayers.

Read: [Heatmaps in OpenLayers](http://acuriousanimal.com/blog/2011/06/06/heatmaps-in-openlayers/)

Demo: [acanimal.github.io/heatmap-openlayers](http://acanimal.github.io/heatmap-openlayers/)
