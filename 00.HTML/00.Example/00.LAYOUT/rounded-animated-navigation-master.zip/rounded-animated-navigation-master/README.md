Rounded Animated Navigation
=========

An experimental full-screen navigation, animated using CSS and jQuery, that expands within a circle.

[Article on CodyHouse](http://codyhouse.co/gem/css-rounded-animated-navigation/)

[Demo](http://codyhouse.co/demo/rounded-animated-navigation/index.html)
 
[Terms](http://codyhouse.co/terms/)
