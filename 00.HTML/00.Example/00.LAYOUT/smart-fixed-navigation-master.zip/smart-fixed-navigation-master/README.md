Smart Fixed Navigation
=========

A fixed navigation that allows your users to access the menu at any time while they are experiencing your website. It's smaller than a full-width fixed header, and replaces the back-to-top button with a smarter UX solution.

[Article on CodyHouse](http://codyhouse.co/gem/smart-fixed-navigation/)

[Demo](http://codyhouse.co/demo/smart-fixed-navigation/index.html)
 
[Terms](http://codyhouse.co/terms/)
