

### Bugs
- Time playback slider sticking out after resize
- Heatmap frozen

### Refactor Tasks
- Refactor Layer configurator component so it works better with the layer API [shan]

### Feature
- Re-implement file upload to use event streaming (no react-palm) [shan]
- Input map style from mapbox style url [shan]
- Map style API to add custom map style [shan]
- Field type editor [shan]
- Export map [javid, shan]

### Remaining UI Update
- Free form color picker [shan]
- Vis config by channel UI (add value switch) [shan]

### Design Request
- More map styles [erik]
