# Grid

![Grid layer](https://d1a3f4spazzrp4.cloudfront.net/kepler.gl/documentation/image21.png "Grid layer")
![3D Grid layer](https://d1a3f4spazzrp4.cloudfront.net/kepler.gl/documentation/image17.png "3D Grid layer")

Grids layers are similar to heatmaps. They show the density of points. They provide visual discrepancy in a map where multiple heatmap-style layers are present.

[Back to table of contents](../a-introduction.md)
