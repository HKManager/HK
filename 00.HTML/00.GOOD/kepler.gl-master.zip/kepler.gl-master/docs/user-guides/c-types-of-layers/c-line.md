# Line

![Line layer](https://d1a3f4spazzrp4.cloudfront.net/kepler.gl/documentation/image3.png "Line layer")

Line layers are the 2D version of arc layers. Both draw a line between two points to represent distance, but in a line layer, the drawing lies flat on the map.

[Back to table of contents](../a-introduction.md)
