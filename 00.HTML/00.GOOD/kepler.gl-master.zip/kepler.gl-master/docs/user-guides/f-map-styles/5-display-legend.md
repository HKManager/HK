# Display Legend
View your map in 3D by clicking the 3D icon in the top right corner of your map:

![Display Legend](https://d1a3f4spazzrp4.cloudfront.net/kepler.gl/documentation/image31.png "Display Legend")

![Sample Legend](https://d1a3f4spazzrp4.cloudfront.net/kepler.gl/documentation/image14.png "Sample Legend")

[Back to table of contents](../a-introduction.md)
