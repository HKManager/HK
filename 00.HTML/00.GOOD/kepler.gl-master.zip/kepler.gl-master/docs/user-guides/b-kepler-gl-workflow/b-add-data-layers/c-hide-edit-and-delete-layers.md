# Hide, Edit and Delete Layers

Each layer has its own tab in the __Data Layers__ menu:
![Hide, edit and delete layers](https://d1a3f4spazzrp4.cloudfront.net/kepler.gl/documentation/image8.png "Hide, edit and delete layers")

Click the __down arrow__ to open up the settings menu for that layer. Click the __trashcan__ to delete a layer. Click the __eye__ to toggle show/hide.

__Note__: The colored line on the left of each layer tab represents what dataset that layer belongs to.

[Back to table of contents](../../a-introduction.md)