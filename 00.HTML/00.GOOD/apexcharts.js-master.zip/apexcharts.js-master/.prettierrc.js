module.exports = {
  semi: false,
  singleQuote: true,
  arrowParens: 'always'
}
