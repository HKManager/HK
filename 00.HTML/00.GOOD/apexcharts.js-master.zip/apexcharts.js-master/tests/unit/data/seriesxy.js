module.exports = [
  {
    data: [
      {
        x: new Date('01/01/2010').getTime(),
        y: 300
      },
      {
        x: new Date('01/02/2010').getTime(),
        y: 230
      },
      {
        x: new Date('01/03/2010').getTime(),
        y: 210
      }
    ]
  }
]
