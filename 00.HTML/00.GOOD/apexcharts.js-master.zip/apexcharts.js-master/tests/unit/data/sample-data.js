module.exports = {
  range: {
    years: [new Date('01/01/2010').getTime(), new Date('01/02/2013').getTime()],
    months: [
      new Date('02/02/2017').getTime(),
      new Date('10/02/2017').getTime()
    ],
    days: [new Date('02/02/2017').getTime(), new Date('02/28/2017').getTime()],
    hours: [
      new Date('02/02/2017 01:20').getTime(),
      new Date('10/10/2017  21:20').getTime()
    ]
  }
}
