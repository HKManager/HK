module.exports = {
  nullData: [
    {
      x: 1994,
      y: 3.5
    },
    {
      x: 1995,
      y: null
    },
    {
      x: 1996,
      y: 5.5
    },
    {
      x: 1997,
      y: null
    },
    {
      x: 1998,
      y: null
    },
    {
      x: 1999,
      y: 4.3
    },
    {
      x: 2000,
      y: 5.4
    },
    {
      x: 2001,
      y: 2.3
    },
    {
      x: 2002,
      y: null
    }
  ]
}
