

## Our Backers and supporters

Financial contributions to ApexCharts go towards ongoing development costs, servers, etc. You can join them in supporting ApexCharts development by visiting our page on [Patreon](patreon.com/junedchhipa)!


### Sponsors
Become a sponsor and get your logo on our website's home-page with a link to your site. [[Become a sponsor](https://www.patreon.com/join/junedchhipa)]

<a href="https://www.santego.fr/?ref=apexcharts.com" target="_blank" style="text-align: center; display: inline-block;"><img src="https://apexcharts.com/media/sponsors/santego.png" width="100" height="100" /></a>

### Backers
Support us with a monthly donation and help us continue our activities. [[Become a backer](https://www.patreon.com/join/junedchhipa/checkout?rid=3043800)].

Backer on | Name
-----|-----
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=10265776" target="_blank">Taillefer Brice</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=17096169" target="_blank">Thomas Janotta</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/calinou/creators" target="_blank">Hugo Locurcio</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=17230063" target="_blank">František Postl</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=3900260" target="_blank">Bob</a>
