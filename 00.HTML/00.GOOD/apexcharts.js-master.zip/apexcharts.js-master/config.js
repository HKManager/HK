import path from 'path'

export const root = path.resolve(__dirname)
